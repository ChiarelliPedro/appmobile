export const fontFamily = {
  regular: "Roboto_400Regular",
  bold: "Roboto_700Bold",
  medium: "Roboto_500Medium",
}
