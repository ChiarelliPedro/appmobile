import "dayjs/locale/pt-br"
import dayjs from "dayjs"

// Para traduzir os nomes de dias e mês para pt-br.
dayjs.locale("pt-br")
