import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

interface ButtonProps {
  title: string;
  onPress: () => void;
}

export function Button({ title, onPress }: ButtonProps) {
  return (
    <TouchableOpacity className="bg-orange-500 p-4 rounded-lg w-full" onPress={onPress}>
      <Text 
        className="text-green-500 text-lg font-bold text-center"
        style={{ fontFamily: 'Roboto_700Bold' }}
      >
        {title}
      </Text>
    </TouchableOpacity>
  );
}