import React from 'react';
import { View, TextInput } from 'react-native';
import { MaterialCommunityIcons, FontAwesome6, MaterialIcons } from '@expo/vector-icons';
import { colors } from '../styles/colors';
import clsx from 'clsx'; 

interface InputProps {
  iconName: string;
  library: 'FontAwesome6' | 'MaterialIcons' | 'MaterialCommunityIcons'; 
  placeholder: string;
  variant?: 'primary' | 'secondary' | 'tertiary'; 
}

export function Input({ iconName, library, placeholder, variant = 'primary' }: InputProps) {
  // Determinar a biblioteca de ícones com base na prop "library"
  let IconComponent;
  switch (library) {
    case 'FontAwesome6':
      IconComponent = FontAwesome6;
      break;
    case 'MaterialIcons':
      IconComponent = MaterialIcons;
      break;
    case 'MaterialCommunityIcons':
    default:
      IconComponent = MaterialCommunityIcons;
  }

  return (
    <View
      className={clsx(
        'w-full h-14 border rounded-lg flex-row items-center gap-2 px-4 mb-4',

        variant === 'primary' && 'border-gray-300',
        variant === 'secondary' && 'border-gray-300 bg-gray-300',
        variant === 'tertiary' && 'border-gray-300 bg-gray-100'
      )}
    >
      <IconComponent
        name={iconName}
        size={20}
        color={colors.green[200]} 
      />
      <TextInput
        className="flex-1 text-lg font-roboto text-gray-300"
        style={{
          lineHeight: 20, 
          color: colors.gray[300],  
        }}
        placeholder={placeholder}
        placeholderTextColor={colors.gray[300]} 
      />
    </View>
  );
}
