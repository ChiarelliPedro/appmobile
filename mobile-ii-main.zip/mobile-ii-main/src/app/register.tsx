import React from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';  // Hook de navegação do expo-router
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { colors } from '../styles/colors';

export default function Register() {
  const router = useRouter();  // Inicializa o hook de navegação

  return (
    <View style={styles.container}>

      <Image 
        source={require('../../assets/images/logo.png')} 
        className="h-16 mb-8" 
        resizeMode="contain"  
      />

      {/* Input p Nome Completo */}
      <Input iconName="user-circle" library="FontAwesome6" placeholder="Nome Completo" variant="primary" />

      {/* Input p E-mail */}
      <Input iconName="alternate-email" library="MaterialIcons" placeholder="E-mail" variant="primary" />

      {/* botao p acessar a credencial */}
      <Button title="CRIAR CREDENCIAL" onPress={() => alert('Credencial criada!')} />

      {/* botao p voltar p a página inicial */}
      <TouchableOpacity onPress={() => router.push('/')}>
        <Text style={styles.infoText}>Já possui ingresso?</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.green[500],
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  infoText: {
    color: colors.gray[200],
    marginTop: 30,
    fontSize: 14,
    fontFamily: 'Roboto_700Bold',
  },
});

