import React from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors } from '../styles/colors'; 
import { useRouter } from 'expo-router';  // Hook de navegação do expo-router
import { Button } from '../components/Button';  
import { Input } from '../components/Input';  

export default function Index() {
  const router = useRouter();  // Inicializa o hook de navegação

  return (
    <View style={styles.container}>

      <Image 
        source={require('../../assets/images/logo.png')} 
        className="h-16 mb-8"  
        resizeMode="contain"   
      />

      {/* Input p o codigo do ingresso */}
      <Input 
        iconName="ticket-confirmation-outline" 
        library="MaterialCommunityIcons" 
        placeholder="Código do Ingresso" 
        variant="primary" 
      />

      {/* Botão p acessar a credencial */}
      <Button title="ACESSAR CREDENCIAL" onPress={() => alert('Credencial acessada!')} />

      {/* Navegar p a tela de registro */}
      <TouchableOpacity onPress={() => router.push('/register')}>
        <Text style={styles.infoText}>Ainda não possui ingresso?</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.green[500],
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  infoText: {
    color: colors.gray[200],
    marginTop: 30, 
    fontSize: 14,
    fontFamily: 'Roboto_700Bold',
  },
});
